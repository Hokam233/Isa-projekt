#include "main.h"

void print_help(){
    printf("This program captures DNS communication. Here is how to use it:\n\n");
    printf("./dns-monitor (-i <interface> | -p <pcapfile>) [-v] [-d <domainsfile>] [-t <translationsfile>]\n\n");
    printf("Options:\n");
    printf(" -h               : Print help.\n");
    printf(" -o               : Print avaible interfaces for option -i.\n");
    printf(" -i <interface>   : Specify the network interface to capture packets from. Valid options include:\n");
    printf("                    eth0 (Ethernet), wlan0 (Wi-Fi), lo (Loopback).\n");
    printf(" -p <pcapfile>    : Specify a PCAP file to read DNS packets from.\n");
    printf("                   Note: Either -i or -p must be specified, but not both.\n");
    printf(" -v               : Verbose mode, providing complete details about DNS messages.\n");
    printf(" -d <domainsfile> : Specify a file to log domain names found in DNS queries.\n");
    printf(" -t <translationsfile> : Specify a file to log domain-to-IP translations.\n\n");
    printf("Note: Only one of -i (interface) or -p (PCAP file) can be used at a time, and one of them is required.\n");
    exit(0);
}

bool check_options(int argc, char *argv[]){

    int c;
    bool interface_mode = false;
    opterr = 0;
    
    while((c = getopt(argc, argv, "i:p:vd:t:ho")) != -1){
        switch(c){
            case 'h':
                print_help();
                break;
            case 'i':
                interface_name = optarg;
                interface_mode = true;
                break;
            case 'p':
                pcapfile_mode = true;
                pcap_file_name = optarg;
                break;
            case 'v':
                verbose_mode = true;
                break;
            case 'd':
                domain_file_mode = true;
                domani_file_name = optarg;
                break;
            case 't':
                translation_mode = true;
                translation_file_name = optarg;
                break;
            case 'o':
                print_device();
                break;
            case '?':
                Error(21, "Invalid starting option.\n", NULL);
                break;
            default://! TODO 
                printf("default in check_optoins TODO\n");
                break;
        }  
        if(interface_mode && pcapfile_mode){
            Error(25, "Wrong input, use -h for help.\n");
        } 

    }
    //xor
    if(interface_mode ^ pcapfile_mode){
        return false;
    }

    return true;
}

int main(int argc, char *argv[]){
    //
    signal(SIGINT, terminate_prog);
    signal(SIGTERM, terminate_prog);  
    signal(SIGQUIT, terminate_prog);
    
    if(check_options(argc, argv)){
        Error(77, "Vstupne parametre nevyhovuju.\nUse -h for help.\n");
    }

    //
    if(interface_name){
        start_program_i(interface_name, verbose_mode, domain_file_mode, 
                    translation_mode, domani_file_name, 
                    translation_file_name);
    }else{
        start_program_f(pcap_file_name, verbose_mode, domain_file_mode, 
                    translation_mode, domani_file_name, 
                    translation_file_name);
    }
    

    return 0;
}