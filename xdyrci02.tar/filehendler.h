#ifndef FILEHENDLER
#define FILEHENDLER

#include <stdio.h>
#include <string.h>

#include "errorhendler.h"

//!Error code for file hendler is 40-49

//opens or create file for -d mode
FILE *open_file(char *filename);
void close_file(FILE *filename);
//look up name in file
int look_up_name(FILE *f, char *name);
//write name down into the file
int write_down_name(FILE *f, char *name);

//for -t mode
int look_up_name_ip(FILE *f, char *name, char *ip);
//
int write_down_name_ip(FILE *f, char *name, char *ip);

#endif