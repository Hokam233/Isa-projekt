#ifndef MAIN
#define MAIN

#include <stdio.h>
#include <time.h>
#include <getopt.h>
#include <stdbool.h>

#include <pcap.h>
#include <netinet/in.h>
#include <netinet/if_ether.h>


//My libreries
#include "errorhendler.h"
#include "sniffer.h"
#include "filehendler.h"

//
#define ETH0 1
#define WLAN0 2
#define LO 3

//global variables//
//
char *interface_name = NULL;
//
bool pcapfile_mode = false;
char *pcap_file_name = NULL;
//for varbose mode
bool verbose_mode = false;
//
bool domain_file_mode = false;
char *domani_file_name = NULL;
//
bool translation_mode = false;
char *translation_file_name = NULL;


//will print how to use the program
void print_help();


#endif