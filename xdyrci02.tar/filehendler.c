#include "filehendler.h"

FILE *open_file(char *filename){
    
    FILE *file = fopen(filename, "a+");
    if( file == NULL){
        Error(44, "Problem with creating or opening a file.\n");
    }

    return file;
}

void close_file(FILE *filename){
    fclose(filename);
}

int look_up_name(FILE *f, char *name){
    if( f == NULL){
        Error(44, "File was not opened.\n");
    }

    char line[256];

    while(fgets(line, sizeof(line), f) != NULL){
        //get rid of the newline character
        line[strcspn(line, "\n")] = '\0';
        
        //compare the name and line in the file
        if(strcmp(line, name) == 0){
            //found name dont write
            return 0;
        }
    }
    
    return 1;
}

int write_down_name(FILE *f, char *name){
    if( f == NULL){
        Error(44, "File was not opened.");
    }

    if( fprintf(f,"%s\n", name) < 0){
        Error(45, "Name was not written to the file.");
    }
    
    return 0;
}

// for -t mode

int look_up_name_ip(FILE *f, char *name, char *ip){
    if( f == NULL){
        Error(44, "File was not opened.\n");
    }
    //domain name max lenght = 253
    //ipv6 max lenght = 39
    //==> 294 + \0 + space =296
    char query[296];

    if( (strlen(name) + strlen(ip)) < 294){
        snprintf(query, sizeof(query), "%s %s", name, ip);
    }else{
        Error(48, "Trying to finde translated domain name.\nDomain name with ip is too long.\n");
    }

    char line[296];

    while(fgets(line, sizeof(line), f) != NULL){
        //get rid of the newline character
        line[strcspn(line, "\n")] = '\0';
        //compare the name and line in the file
        if( strcmp(line, query) == 0){
            return 0;
        }
    }
    
    return 1;
}

int write_down_name_ip(FILE *f, char *name, char *ip){
    if( f == NULL){
        Error(44, "File was not opened.");
    }

    if( fprintf(f,"%s %s\n", name, ip) < 0){
        Error(45, "Name was not written to the file.");
    }
    
    return 0;
}