#ifndef ERRORHENDLER
#define ERRORHENDLER 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <stdarg.h>

//for closing the sniffing
#include <pcap.h>
#include "sniffer.h"

//forward declaration of imp_data
struct imp_data;
//sniffer.h
extern  pcap_t *global_handle;
extern  pcap_if_t *global_all_devs;
//pcap file
extern FILE *global_file_pcap;


//function for handling fatal errors
//it terminate the program
void Error(int err_code, char *format, ...);

//function for handling non fatal errors
int Warning(int err_code, char *format, ...);

//funciton to hande  free all the malloced memory
void exit_hendler();

//function to hendle ctrl+c signal
void terminate_prog(int sig);

#endif