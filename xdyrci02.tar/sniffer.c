#include "sniffer.h"

//global 
char Err_buf_sniffer[PCAP_ERRBUF_SIZE];
pcap_t *global_handle = NULL;
pcap_if_t *global_all_devs = NULL;
bool global_domain_file_mode = false;
bool global_translation_file_mode = false;
FILE *global_file_pcap = NULL;
char *global_file_name_d = NULL;
char *global_file_name_t = NULL;

void print_device() {
    pcap_if_t *alldevs;
    pcap_if_t *device;

    if (pcap_findalldevs(&alldevs, Err_buf_sniffer) == -1) {
        Warning(95, Err_buf_sniffer);
    }

    //check if any devices were found
    if (alldevs == NULL) {
        fprintf(stderr, "No devices found.\n");
        exit(91);
    }

    //
    printf("Available devices:\n");
    for (device = alldevs; device != NULL; device = device->next) {

        //filter for active interfaces
        if (device->flags & PCAP_IF_UP) {
            
            printf("Device: %s", device->name);

            //check for description
            if (device->description) {
                printf(" (%s)", device->description);
            } else {
                printf(" (No description available)");
            }

            //check if its vlan
            if (strstr(device->name, ".") != NULL) {
                printf(" - VLAN Interface");
            }
            printf("\n");
        }
        
    }

    //free the device list
    pcap_freealldevs(alldevs);
    exit(0);
}

int network_layer_length(const u_char *packet){
    int tmp = pcap_datalink(global_handle);
    int length = -1;
    switch(tmp){
        case DLT_NULL:      //loopback
            length = LOOPBACK_HDR_LEN;
            break;
        case DLT_EN10MB:    //ethernet
            length = ETHERNET_HEADER_LEN;
            break;
        case DLT_RAW:       //without network header
            length = 0;
            break;
        case DLT_IEEE802_11://wifi 
            length = calculate_wifi_hdr(packet);
            break;
        case DLT_LINUX_SLL2://for any option
            length = 20;
            break;
        case DLT_LINUX_SLL:
            length = 16;
            break;
        default:
            Error(99, "Cant determinate network header lenght. LINKTYPE_value %d\n", tmp);
            break;
    }

    return length;
}

int calculate_wifi_hdr(const u_char *packet){
    uint8_t hdr_len = WIFI_HDR_LEN_MIN;
    //extract the frame control
    uint16_t frame_control = (packet[0] | (packet[1] << 8));

    //check To DS and From DS 
    if( (frame_control & 0x0100) && (frame_control & 0x0200) ){
        hdr_len = WIFI_HDR_LEN_MAX;
    }

    //check for QoS control field
    if(frame_control    & 0x0080){
        hdr_len += QOS_LEN; // in B
    }

    //check for HT control field
    if(frame_control & 0x0400){
        hdr_len += HT_CONTROL_LEN; // in B
    }

    return hdr_len;
}

int ip_hdr_extract(const u_char *packet, int net_hdr_len, char *src_ip, char *dst_ip){
    uint8_t version = packet[net_hdr_len] >> 4;
    const struct ip *ip_hdr;
    const struct ip6_hdr *ip6_hdr;
    int ip_len = 0;
    if(version == 4){
        ip_hdr = (struct ip*)(packet + net_hdr_len);
        
        inet_ntop(AF_INET, &(ip_hdr->ip_src), src_ip, INET_ADDRSTRLEN);
        inet_ntop(AF_INET, &(ip_hdr->ip_dst), dst_ip, INET_ADDRSTRLEN);  
        
        ip_len = ip_hdr->ip_hl * 4;
    }else if(version == 6){
        ip6_hdr = (struct ip6_hdr*)(packet+net_hdr_len);
        
        inet_ntop(AF_INET6, &(ip6_hdr->ip6_src), src_ip, INET6_ADDRSTRLEN);
        inet_ntop(AF_INET6, &(ip6_hdr->ip6_dst), dst_ip, INET6_ADDRSTRLEN);

        ip_len = IP6_HDR_LEN;
    }else{
        Error(99, "Unknow error in ip header.\n");
    }

    return ip_len;
}

void transport_layer_extract(const u_char *packet, int net_hdr_len, int ip_hdr_len, uint16_t *src_port, uint16_t *dst_port){
    const u_char *tmp = packet + net_hdr_len + ip_hdr_len;
    *src_port = ntohs(*(uint16_t*)(tmp));
    *dst_port = ntohs(*(uint16_t*)(tmp+2));
}

void print_dns_short(const struct pcap_pkthdr *header, const u_char *packet){
     //for time
    struct tm *ltime;
    time_t local_tv_sec;
    char timestr[21];
    //ip, give it ip6 len to be able to store ipv4 and ipv6
    char src_ip[INET6_ADDRSTRLEN];
    char dst_ip[INET6_ADDRSTRLEN];

    //ports
    uint16_t src_port, dst_port;
    //dns header
    uint16_t qdcount, ancount, nscount, arcount;
    uint8_t QR;
    
    //extract time 
    local_tv_sec = header->ts.tv_sec;
    ltime = localtime(&local_tv_sec);
    strftime(timestr, sizeof(timestr), "%Y-%m-%d %H:%M:%S", ltime);

    //skip network layer
    int net_hdr_len = network_layer_length(packet);
    //extract data from internet layer and store them in imp_data, and return internet header length
    int internet_hdr_len = ip_hdr_extract(packet, net_hdr_len, src_ip, dst_ip);
    //transport layer, extract ports
    transport_layer_extract(packet, net_hdr_len, internet_hdr_len, &src_port, &dst_port);
    //aplication layer
    ns_msg dns_data_handle;
    //get to the dns data
    const u_char *dns = (packet + net_hdr_len + internet_hdr_len + UDP_HDR_LEN );
    int dns_len = header->len - (net_hdr_len + internet_hdr_len + UDP_HDR_LEN);

    if(ns_initparse(dns, dns_len, &dns_data_handle) == -1){
        Error(99, "Can`t parse the dns packet.\n");
    }
    
    QR  = ns_msg_getflag(dns_data_handle, ns_f_qr);
    //get the count
    qdcount = ns_msg_count(dns_data_handle, ns_s_qd);
    ancount = ns_msg_count(dns_data_handle, ns_s_an);
    nscount = ns_msg_count(dns_data_handle, ns_s_ns);
    arcount = ns_msg_count(dns_data_handle, ns_s_ar);

    const u_char *eomorig = dns + dns_len;
    if(global_domain_file_mode){
        d_mode(qdcount, ancount, nscount, arcount, dns_data_handle, dns, eomorig);
    }

    if(global_translation_file_mode){
        t_mode( ancount, arcount, dns_data_handle);
    }
    
    
    printf("%s %s -> %s (%c %d/%d/%d/%d)\n", timestr, src_ip, dst_ip, (QR ? 'R' : 'Q'),
                                            qdcount, ancount, nscount, arcount);
}

void write_domain_name(char *domain_name){
    
    FILE *f = open_file(global_file_name_d);
    if(look_up_name(f, domain_name) == 1){
        write_down_name(f, domain_name);
    }
    close_file(f);
}

void d_mode(u_int16_t qdcount, u_int16_t ancount, uint16_t nscount, uint16_t arcount, ns_msg dns_data_handle, const u_char *dns, const u_char *eomorig){
    ns_rr data_section;
    char tmp[SAFE_DST];
    if(qdcount){
        for(int i = 0; i < qdcount; i++){
            if (ns_parserr(&dns_data_handle, ns_s_qd, i, &data_section) == -1) {
                Error(99, "Failed to parse question section.\n");
            }
            get_dns_name(data_section, tmp);
            
        }
    }

    if(ancount){
        for(int i = 0; i < ancount; i++){
            if (ns_parserr(&dns_data_handle, ns_s_an, i, &data_section) == -1) {
                Error(99, "Failed to parse answer section.\n");
            }
            get_dns_name(data_section, tmp);
            //get name from rdata if NS
            if(ns_rr_type(data_section) == T_NS){
                if(ns_name_uncompress(dns, eomorig, ns_rr_rdata(data_section), tmp, sizeof(tmp)) == -1){
                    Error(99, "Failed to uncompress name.\n");
                }
                write_domain_name(tmp);
            } 
        }
    }

    if(nscount){
        for(int i = 0; i < nscount; i++){
            if (ns_parserr(&dns_data_handle, ns_s_ns, i, &data_section) == -1) {
                Error(99, "Failed to parse authority section.\n");
            }
            get_dns_name(data_section, tmp);
            //get name from rdata if NS
            if(ns_rr_type(data_section) == T_NS){
                if(ns_name_uncompress(dns, eomorig, ns_rr_rdata(data_section), tmp, sizeof(tmp)) == -1){
                    Error(99, "Failed to uncompress name.\n");
                }
                write_domain_name(tmp);
            } 
        }
    }   

    if(arcount){
        for(int i = 0; i < arcount; i++){
            if (ns_parserr(&dns_data_handle, ns_s_ar, i, &data_section) == -1) {
                Error(99, "Failed to parse adicional section.\n");
            }
            get_dns_name(data_section, tmp);
            //get name from rdata if NS
            if(ns_rr_type(data_section) == T_NS){
                if(ns_name_uncompress(dns, eomorig, ns_rr_rdata(data_section), tmp, sizeof(tmp)) == -1){
                    Error(99, "Failed to uncompress name.\n");
                }
                write_domain_name(tmp);
            } 
        }
    }
}

void write_translation(char *domain_name, char *ip){
    FILE *f = open_file(global_file_name_t);
    if(look_up_name_ip(f, domain_name, ip) == 1){
        write_down_name_ip(f, domain_name, ip);
    }
    close_file(f);
}

void t_mode( u_int16_t ancount, uint16_t arcount, ns_msg dns_data_handle){
    ns_rr data_section;
    char name[SAFE_DST];
    char ip[SAFE_DST];
    if(ancount){
        for(int i = 0; i < ancount; i++){
            if (ns_parserr(&dns_data_handle, ns_s_an, i, &data_section) == -1) {
                Error(99, "Failed to parse answer section.\n");
            }
            get_dns_name(data_section, name);
            //get name from rdata if NS
            if(ns_rr_type(data_section) == T_A) {

                inet_ntop(AF_INET, ns_rr_rdata(data_section), ip, INET_ADDRSTRLEN);

                write_translation(name, ip);
            } else if(ns_rr_type(data_section) == T_AAAA){
                inet_ntop(AF_INET6, ns_rr_rdata(data_section), ip, INET6_ADDRSTRLEN);
                write_translation(name, ip);
            }
        }
    }

    if(arcount){
        for(int i = 0; i < arcount; i++){
            if (ns_parserr(&dns_data_handle, ns_s_ar, i, &data_section) == -1) {
                Error(99, "Failed to parse adicional section.\n");
            }
            get_dns_name(data_section, name);
            //get name from rdata if NS
            if(ns_rr_type(data_section) == T_A) {

                inet_ntop(AF_INET, ns_rr_rdata(data_section), ip, INET_ADDRSTRLEN);

                write_translation(name, ip);
            } else if((ns_rr_type(data_section) == T_AAAA)){
                inet_ntop(AF_INET6, ns_rr_rdata(data_section), ip, INET6_ADDRSTRLEN);
                write_translation(name, ip);
            }
        }
    }
}

bool get_qtype(ns_rr dns_data, char *dst){
    switch(ns_rr_type(dns_data)){
            case T_A:       
                strcpy(dst, "A");
                break;
            case T_AAAA:       
                strcpy(dst, "AAAA");                     
                break;
            case T_NS:       
                strcpy(dst, "NS");                      
                break;
            case T_MX:           
                strcpy(dst, "MX");                
                break;
            case T_SOA:          
                strcpy(dst, "SOA");                   
                break;
            case T_CNAME:
                strcpy(dst, "CNAME"); 
                break;
            case T_SRV:
                strcpy(dst, "SRV"); 
                break;
            default:
                strcpy(dst, "Unsuported type"); 
                return true;
        }
    return false;
}

bool get_qclass(ns_rr dns_data, char *dst){
    switch (ns_rr_class(dns_data)){
            case C_IN:
                strcpy(dst, "IN");
                break;
            case C_ANY:
                strcpy(dst, "ANY");
                break;
            case C_CHAOS:
                strcpy(dst, "CH");
                break;
            case C_HS:
                strcpy(dst, "HS");
                break;
            case C_NONE:
                strcpy(dst, "NONE");
                break;
            default:
                strcpy(dst, "Reserved or unasigned.");
                return true;
        }
    return false;
}

//dns => pointer to offset of the dns
void get_dns_name( ns_rr dns_data, char *dst){
    char *raw_name = ns_rr_name(dns_data);
                                //name is not compressed
    strcpy(dst, raw_name);
    if(global_domain_file_mode){
        write_domain_name(dst);
    }
    strcat(dst, ".");
}

void get_dns_rdata(const u_char *dns, const u_char *eomorig, ns_rr dns_data, char *dst){
    const u_char *raw_data = ns_rr_rdata(dns_data);
    int rd_len = (ns_rr_rdlen(dns_data)+1)*4;
    char uncompressed[rd_len];
    dst[0] = '\0';
    //clear the dst
    memset(dst, 0, SAFE_DST);
    switch(ns_rr_type(dns_data)){                        //ipv4 and ipv6 dosnt compress
        case T_A:
            inet_ntop(AF_INET, raw_data, dst, INET_ADDRSTRLEN);
            break;
        case T_AAAA:
            inet_ntop(AF_INET6, raw_data, dst, INET6_ADDRSTRLEN);
            break;
        case T_SOA:{
            const u_char *current = raw_data;

            //get mname
            int offset = ns_name_uncompress(dns, eomorig, current, uncompressed, sizeof(uncompressed));
            if (offset < 0) {
                Error(99, "Failed to uncompress SOA MNAME.\n");
            }
            strcpy(dst, uncompressed);  
            if(global_domain_file_mode){
                write_domain_name(dst);
            }
            strcat(dst, ". ");          
            current += offset;

            //get rname
            offset = ns_name_uncompress(dns, eomorig, current, uncompressed, sizeof(uncompressed));
            if (offset < 0) {
                Error(99, "Failed to uncompress SOA RNAME.\n");
            }
            strcat(dst, uncompressed);  
            if(global_domain_file_mode){
                write_domain_name(uncompressed);
            }
            strcat(dst, ". ");
            current += offset;
            //the rest of the soa, serial, refresh, retry, expire, ttl
            uint32_t number;
            char to_str[16];
            for(int i = 0; i < 5; i++){  
                number = ntohl(*(const uint32_t*)current);
                current += sizeof(uint32_t);
                snprintf(to_str, sizeof(to_str), "%u", number);
                strcat(dst, to_str);
                strcat(dst, " ");
            }
            
            break;
            }
        case T_NS:                      //same as default but need to extract domain name from rdata
            if(ns_name_uncompress(dns, eomorig, ns_rr_rdata(dns_data), uncompressed, sizeof(uncompressed)) == -1){
                    Error(99, "Failed to uncompress name.\n");
            }
            strcpy(dst, uncompressed);
            if(global_domain_file_mode){
                write_domain_name(dst);
            }
            strcat(dst, ".");
            break;
        case T_MX:{
            const u_char *current = raw_data;

            //get the preference value
            uint16_t priority = ntohs(*(const uint16_t *)current);
            current += sizeof(uint16_t);
            char to_str[16];
            //get the mail exchange domain name
            int offset = ns_name_uncompress(dns, eomorig, current, uncompressed, sizeof(uncompressed));
            if (offset < 0) {
                Error(99, "Failed to uncompress MX name.\n");
            }

            //format the preference and domain name into dst
            snprintf(to_str, sizeof(to_str), "%u", priority);

            if(global_domain_file_mode){
                write_domain_name(uncompressed);
            }
            strcpy(dst, to_str);
            strcat(dst, " ");
            strcat(dst, uncompressed);
            strcat(dst, ".");
            break;
            }
        default:                                           
            
            if(ns_name_uncompress(dns, eomorig, ns_rr_rdata(dns_data), uncompressed, sizeof(uncompressed)) == -1){
                    Error(99, "Failed to uncompress name.\n");
            }
            strcpy(dst, uncompressed);
            strcat(dst, ".");
            break;
    }
}

void process_ans_s(ns_rr data_section, int ancount, ns_msg dns_data_handle, const u_char *dns, const u_char *eomorig){
    char dns_type[BUFFER_LEN];
    char dns_class[BUFFER_LEN];
    char name[MAXDNAME];
    
    printf("[Answer Section]\n");
    //process the ans section
    for(int i=0; i < ancount; i++){
        if(ns_parserr(&dns_data_handle, ns_s_an, i, &data_section) == -1){
            Error(99, "Failed to parse answer section.\n");
        }

        if(get_qtype(data_section, dns_type)){
            printf("%s\n", dns_type);
            continue;
        }
        
        if(get_qclass(data_section, dns_class)){
            printf("%s\n", dns_class);
            continue;
        }
        
        char r_data[SAFE_DST];
        get_dns_name( data_section, name);

        get_dns_rdata(dns, eomorig, data_section, r_data);
        
        printf("%s %d %s %s %s\n", name, ns_rr_ttl(data_section), dns_class, dns_type, r_data);
    }
    printf("\n");
}

void process_auth_s(ns_rr data_section, int nscount, ns_msg dns_data_handle, const u_char *dns, const u_char *eomorig){
    char dns_type[BUFFER_LEN];
    char dns_class[BUFFER_LEN];
    char name[MAXDNAME];
    
    
    printf("[Authority Section]\n");

    //authority section
    for(int i=0; i < nscount; i++){
        if(ns_parserr(&dns_data_handle, ns_s_ns, i, &data_section) == -1){
            Error(99, "Failed to parse answer section.\n");
        }
        
        if(get_qtype(data_section, dns_type)){
            printf("%s\n", dns_type);
            continue;
        }

        if(get_qclass(data_section, dns_class)){
            printf("%s\n", dns_class);
            continue;
        }
        
        char r_data[SAFE_DST];
        
        get_dns_name( data_section, name);
        get_dns_rdata(dns, eomorig, data_section, r_data);

        printf("%s %d %s %s %s\n", name, ns_rr_ttl(data_section), dns_class, dns_type, r_data);
    }
    printf("\n");
}

void process_addi_s(ns_rr data_section, int arcount, ns_msg dns_data_handle, const u_char *dns, const u_char *eomorig){
    char dns_type[BUFFER_LEN];
    char dns_class[BUFFER_LEN];
    
    printf("[Additional Section]\n");

    //addition seciton
    for(int i=0; i < arcount; i++){
        if(ns_parserr(&dns_data_handle, ns_s_ar, i, &data_section) == -1){
            Error(99, "Failed to parse answer section.\n");
        }
        if(get_qtype(data_section, dns_type)){
            printf("%s\n", dns_type);
            continue;
        }

        if(get_qclass(data_section, dns_class)){
            printf("%s\n", dns_class);
            continue;
        }
        char name[MAXDNAME];
        
        char r_data[SAFE_DST];
        get_dns_name( data_section, name);
        get_dns_rdata(dns, eomorig, data_section, r_data);

        printf("%s %d %s %s %s\n", name, ns_rr_ttl(data_section), dns_class, dns_type, r_data);
    }
    printf("\n");
}

void print_dns_long(const struct pcap_pkthdr *header, const u_char *packet){
    
     //for time
    struct tm *ltime;
    time_t local_tv_sec;
    char timestr[21];
    //ip
    char src_ip[INET6_ADDRSTRLEN];
    char dst_ip[INET6_ADDRSTRLEN];

    //ports
    uint16_t src_port, dst_port;
    //dns header
    uint16_t id, qdcount, ancount, nscount, arcount;
    uint8_t QR, OPCODE, AA, TC, RA, RD, AD, CD, RCODE;
    
    //extract time 
    local_tv_sec = header->ts.tv_sec;
    ltime = localtime(&local_tv_sec);
    strftime(timestr, sizeof(timestr), "%Y-%m-%d %H:%M:%S", ltime);

    //skip network layer
    int net_hdr_len = network_layer_length(packet);
    //extract data from internet layer and store them in imp_data, and return internet header length
    int internet_hdr_len = ip_hdr_extract(packet, net_hdr_len, src_ip, dst_ip);
    //transport layer, extract ports
    transport_layer_extract(packet, net_hdr_len, internet_hdr_len, &src_port, &dst_port);
    //aplication layer
    ns_msg dns_data_handle;

    //get to the dns data
    const u_char *dns = (packet + net_hdr_len + internet_hdr_len + UDP_HDR_LEN );
    int dns_len = header->len - (net_hdr_len + internet_hdr_len + UDP_HDR_LEN);
    
    
    if(ns_initparse(dns, dns_len, &dns_data_handle) == -1){
        Error(99, "Can`t parse the dns packet.\n");
    }
    
    id = ns_msg_id(dns_data_handle);
    //get all the flags
    QR = ns_msg_getflag(dns_data_handle, ns_f_qr);
    OPCODE = ns_msg_getflag(dns_data_handle, ns_f_opcode);
    AA = ns_msg_getflag(dns_data_handle, ns_f_aa);
    TC = ns_msg_getflag(dns_data_handle, ns_f_tc);
    RD = ns_msg_getflag(dns_data_handle, ns_f_rd);
    RA = ns_msg_getflag(dns_data_handle, ns_f_ra);
    AD = ns_msg_getflag(dns_data_handle, ns_f_ad);
    CD = ns_msg_getflag(dns_data_handle, ns_f_cd);
    RCODE = ns_msg_getflag(dns_data_handle, ns_f_rcode);
    //get the count
    qdcount = ns_msg_count(dns_data_handle, ns_s_qd);
    ancount = ns_msg_count(dns_data_handle, ns_s_an);
    nscount = ns_msg_count(dns_data_handle, ns_s_ns);
    arcount = ns_msg_count(dns_data_handle, ns_s_ar);

    //get question
    ns_rr data_section;
    char dns_type[BUFFER_LEN];
    char dns_class[BUFFER_LEN];
    char dns_name[MAXDNAME];
    const u_char *eomorig = dns + dns_len;

    printf("Timestamp: %s\n", timestr);
    printf("SrcIP: %s\n", src_ip);
    printf("DstIP: %s\n", dst_ip);
    printf("SrcPort: UDP/%d\n", src_port);
    printf("DstPort: UDP/%d\n", dst_port);
    printf("Identifier: %#x\n", id);
    printf("Flags: QR=%d, OPCODE=%d, AA=%d, TC=%d, RD=%d, RA=%d, AD=%d, CD=%d, RCODE=%d\n", QR, OPCODE, AA, TC, RD,
                                                                                            RA, AD, CD, RCODE);

    printf("\n[Question Section]\n");
    //process Question Section
    for (int i = 0; i < qdcount; i++) {
        if (ns_parserr(&dns_data_handle, ns_s_qd, i, &data_section) == -1) {
            Error(99, "Failed to parse question section.\n");
        }
        
        if(get_qtype(data_section, dns_type)){
            printf("%s\n", dns_type);
            continue;
        }
        
        if(get_qclass(data_section, dns_class)){
            printf("%s\n", dns_class);
            continue;
        }

        get_dns_name( data_section, dns_name);

        printf("%s %s %s\n", dns_name, dns_class, dns_type);
    }
    printf("\n");

    if(ancount){
        process_ans_s(data_section, ancount, dns_data_handle, dns, eomorig);
    }
    if(nscount){
        process_auth_s(data_section, nscount, dns_data_handle, dns, eomorig);
    }
    if(arcount){
        process_addi_s(data_section, arcount, dns_data_handle, dns, eomorig);
    }

    if(global_translation_file_mode){
        t_mode(ancount, arcount, dns_data_handle);
    }
    //end
    printf("====================\n");
}

//! -- //

//callback function 
void handle_packet(u_char *user_data, const struct pcap_pkthdr *header, const u_char *packet){
    struct program_data *data = (struct program_data *)user_data;
    
    if(data->verbose_mode){
        print_dns_long(header, packet);
    }else{
        print_dns_short(header, packet);
    }

} 

void handle_pcap(u_char *user_data, const struct pcap_pkthdr *header, const u_char *packet){
    struct program_data *data = (struct program_data *)user_data;
    
    if(data->verbose_mode){
        print_dns_long(header, packet);
    }else{
        print_dns_short(header, packet);
    }

} 


void sniff(char *name, struct program_data *pr_data){
    struct bpf_program fp;
    char filter_exp[] = "udp port 53";
    bpf_u_int32 mask;
    bpf_u_int32 net;
    //
    pcap_if_t *dev;

    if( pcap_findalldevs(&global_all_devs, Err_buf_sniffer) == -1){
        Warning(94, "Cant get the divace.\nErrorbuff: %s\n", Err_buf_sniffer);
    }

    if(global_all_devs == NULL){
        Warning(95, "There is no devaice to sniff on.");
    }

    //go thru devacies
    for(dev = global_all_devs; dev->next != NULL; dev = dev->next){
        if(!strcmp(dev->name, name)){
            break;
        }
    }
    //check if dev was found
    if(dev == NULL){
        Error(99, "Device provaided was not found. Use -o to list avaible divaces.\n");
    }
   
    //finde the properties for the device 
    if(pcap_lookupnet(dev->name, &net, &mask, Err_buf_sniffer) == -1){
        Warning(94, "Couldn`t get netmask for: %s.\nErrorbuff: %s\n", dev->name, Err_buf_sniffer);
        net = 0;
        mask = 0;
    }

    //open for sniffing 
    global_handle = pcap_open_live(dev->name, BUFSIZ, 1, 1000, Err_buf_sniffer);
    if(global_handle == NULL){
        Warning(99, "ERROR: opening device\n ERRBUFF: %s\n", Err_buf_sniffer);
        return;
    }

    //compile and apply the filter 
    if(pcap_compile(global_handle, &fp, filter_exp, 0, net) == -1){
        Warning(99, "ERR: with compiling the filter.\n ERRBUF: %s\n", Err_buf_sniffer);
    }

    if(pcap_setfilter(global_handle, &fp) == -1){
        Warning(99, "ERRR: with applying the filter.\nERRBUF: %s\n", Err_buf_sniffer);
    }

    pcap_freecode(&fp);

    pcap_loop(global_handle, -1, handle_packet, (u_char *)pr_data);
}

void start_program_i(char *name, bool verbose_mode, bool domain_file_mode, 
                    bool translation_mode, char *domain_name_f, 
                    char *translation_name_f){

    //create struct for data
    struct program_data pr_data;
    pr_data.verbose_mode = verbose_mode;
    pr_data.doman_name_f = domain_name_f;
    pr_data.translation_name_f = translation_name_f;

    //fill the globals
    global_domain_file_mode = domain_file_mode;
    global_translation_file_mode = translation_mode;

    //open file for domain names
    if(global_domain_file_mode){
        global_file_name_d = domain_name_f;
    }
    
    if(global_translation_file_mode){
        global_file_name_t = translation_name_f;
    }
    
    sniff(name, &pr_data);

}

void start_program_f(char *name, bool verbose_mode, bool domain_file_mode, 
                    bool translation_mode, char *domain_name_f, 
                    char *translation_name_f){

    
    struct program_data pr_data;
    pr_data.verbose_mode = verbose_mode;
    pr_data.doman_name_f = domain_name_f;
    pr_data.translation_name_f = translation_name_f;
    
    //fill the globals
    global_domain_file_mode = domain_file_mode;
    global_translation_file_mode = translation_mode;

    //open file for domain names
    if(global_domain_file_mode){
        global_file_name_d = domain_name_f;
    }
   
    if(global_translation_file_mode){
        global_file_name_t = translation_name_f;
    }
   
    const char *filter_exp = "udp port 53";

    global_handle = pcap_open_offline(name, Err_buf_sniffer);
    if (global_handle == NULL){
        Error(99, "Can`t open pcap file.\n");
    }
    struct bpf_program fp;
    if (pcap_compile(global_handle, &fp, filter_exp, 0, PCAP_NETMASK_UNKNOWN) == -1) {
        Error(99, "Couln`t compile filter.\n");
    }
    if (pcap_setfilter(global_handle, &fp) == -1) {
        Error(99, "Couln`t set filter.\n");
    }
    pcap_loop(global_handle, -1, handle_pcap, (u_char *)&pr_data);
}