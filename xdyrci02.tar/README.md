# ISA-dns-monitoring

**Autor:** Jakub Dyrčík  
**Login:** xdyrci02  

Tento program slúži na zachytávanie DNS komunikácie cez protokol UDP na porte 53. Je kompatibilný so zariadeniami využívajúcimi **Ethernet**, **Wi-Fi**, **loopback** a podporuje aj možnosť `any`, avšak jej dostupnosť závisí od prostredia (napr. na Merline nebolo možné testovať, no na Ubuntu funguje správne).

## Funkcionalita
Program podporuje:
- Výpis dostupných sieťových zariadení prostredníctvom prepínača `-o`.
- Výpis nápovedy pomocou prepínača `-h`.
- Zachytávanie DNS komunikácie na špecifikovanom zariadení s možnosťou použitia voliteľného verbose režimu (`-v`).

### Príklad spustenia:
```bash
make
sudo ./dns-monitor -i lo -v
```

### Odovzdané súbory:
- main.c.
- main.h
- errorhendler.c
- errorhendler.h
- sniffer.c
- sniffer.h
- filehendler.c
- filehendler.h
- Makefile
- README.md
- manual.pdf