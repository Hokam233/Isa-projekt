#include "errorhendler.h"


void Error(int err_code, char *format, ...){
    
    va_list args;

    va_start(args, format);
    fprintf(stderr, "ERR: ");
    vfprintf(stderr, format, args);
    va_end(args);

    terminate_prog(0);
    exit(err_code);
}

int Warning(int err_code, char *format, ...){

    va_list args;

    va_start(args, format);

    fprintf(stderr, "Warning: ");
    vfprintf(stderr, format, args);

    va_end(args);

    return err_code;
}


void terminate_prog(int sig){
    (void)sig;

    //free all the memory
    //stuff from sniffer
    if(global_handle != NULL){
        pcap_close(global_handle);
    }
    if(global_all_devs != NULL){
        pcap_freealldevs(global_all_devs);
    }
    if(global_file_pcap != NULL){
        fclose(global_file_pcap);
    }

    //exit with correct return
    exit(0);
}