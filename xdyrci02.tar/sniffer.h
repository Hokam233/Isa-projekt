//For interntet funcitons
#ifndef SNIFFER
#define SNIFFER

#include "errorhendler.h"
#include "filehendler.h"

#include <stdio.h>
#include <pcap.h>
#include <netinet/in.h>
#include <netinet/if_ether.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/udp.h>
#include <time.h>
#include <stdbool.h>

#include <sys/types.h>
#include <arpa/nameser.h>
#include <resolv.h>


// -- Number in bytes -- //
#define WIFI_HDR_LEN_MAX 30
#define WIFI_HDR_LEN_MIN 24
#define HT_CONTROL_LEN 4
#define QOS_LEN 2
#define ETHERNET_HEADER_LEN 14
#define VLAN_ETHERNET_HEDER_LEN 18
#define LOOPBACK_HDR_LEN 4
#define IP6_HDR_LEN 40
#define UDP_HDR_LEN 8             //transport header we are using filter for the udp so only 8B will be in transport header
#define DNS_HDR_LEN 12
#define BUFFER_LEN 255
#define SAFE_DST 512

//struct for the call back function
struct program_data{
    bool verbose_mode;
    char *doman_name_f;
    char *translation_name_f;
};

//buffer for error massages
extern char Err_buf_sniffer[PCAP_ERRBUF_SIZE];
//global variables
extern  struct imp_data *global_imp_data;
extern  pcap_t *global_handle;
extern  pcap_if_t *global_all_devs;
extern bool global_domain_file_mode;
extern bool global_translation_file_mode;
//pcap file
extern FILE *global_file_pcap;


//start the sniffing on given interface with the given options
void start_program_i(char *name, bool verbose_mode, bool domain_file_mode, 
                    bool translation_mode, char *domain_name_f, 
                    char *translation_name_f);

//start the sniffing on given pcap file
void start_program_f(char *name, bool verbose_mode, bool domain_file_mode, 
                    bool translation_mode, char *domain_name_f, 
                    char *translation_name_f);
//capture udp communication
void sniff(char *name, struct program_data *pr_data);
//print all avaible divaces, for --help
void print_device();
//callback funciton for pcap_loop
void hendle_packet(u_char *user_data, const struct pcap_pkthdr *header, const u_char *packet);
//handles printing of the short version
void print_dns_short(const struct pcap_pkthdr *header, const u_char *packet);
//handles printing of the long version
void print_dns_long(const struct pcap_pkthdr *header, const u_char *packet);
//expect packet in its full size as it was captured
int calculate_wifi_hdr(const u_char *packet);
//will store src and dst ip and return the length of ip header
int ip_hdr_extract(const u_char *packet, int net_hdr_len, char *src_ip, char *dst_ip);
//extract information from udp header
void transport_layer_extract(const u_char *packet, int net_hdr_len, int ip_hdr_len, uint16_t *src_port, uint16_t *dst_port);
//extract information from the data
void dns_data(const u_char *packet, int net_hdr_len, int ip_hdr_len);
//get the name from the packet
void get_dns_name(ns_rr dns_data, char *dst);
//print information for the -d mode
void d_mode(u_int16_t qdcount, u_int16_t ancount, uint16_t nscount, uint16_t arcount, ns_msg dns_data_handle, const u_char *dns, const u_char *eomorig);
//help function that will print information inot the file for -f
void write_translation(char *domain_name, char *ip);
//print the information for the -f mode
void t_mode( u_int16_t ancount, uint16_t arcount, ns_msg dns_data_handle);
#endif